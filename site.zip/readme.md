1. git clone 
2. cd portfolio-site
3. bower i
4. npm i
5. gulp 